#
# NOTICE
#
# While FaceFXWrapper does produce LIP files for the 64-bit CreationKit, it
# has not been validated for correctness. Use at your own risk.
#
# 'FaceFXWrapper.exe' must be in the directory '<SKYRIM_DIR>\Tools\Audio'.
# 
# REQUIREMENTS
#
# FonixData.cdx is a proprietary file required for FaceFX. You can obtain FonixData
# from the Fallout 3, Fallout 4, or Skyrim LE CreationKit files. It must be placed
# in '<SKYRIM_DIR>\Data\Sound\Voice\Processing'.
#
