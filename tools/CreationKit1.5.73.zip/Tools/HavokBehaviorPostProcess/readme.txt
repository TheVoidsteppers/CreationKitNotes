
-----------------------------------------------------------------
Skyrim SE Creation Kit HavokBehaviorPostProcess tool
-----------------------------------------------------------------

HavokBehaviorPostProcess.exe is a tool to upgrade havok animation files (*.HKX) files for use with Skyrim Special Edition.

File Usage :  HavokBehaviorPostProcess.exe --platformamd64 inputfile.hkx outputfile.hkx

A sample windows batch file has been supplied to batch process your assets.

